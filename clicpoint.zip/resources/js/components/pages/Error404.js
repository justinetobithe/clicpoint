import React from 'react';

export default function Error404() {
    return (
        <div>
            <p>Error 404: Page Not Found</p>
        </div>
    );
}
