import React from 'react'

export default function ViewDoctor() {
    return (
        <div>ViewDoctor</div>
    )
}
