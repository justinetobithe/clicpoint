import React from 'react'

export default function AddDoctor() {
    return (
        <div>AddDoctor</div>
    )
}
