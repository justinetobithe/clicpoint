import React from 'react'

export default function ViewPatientModal() {
    return (
        <div>ViewPatientModal</div>
    )
}
