import React from 'react'

export default function EditImmunizationData() {
    return (
        <div>EditImmunizationData</div>
    )
}
